package com.revature.foundation_project.menu;

public class Menu {
	
	public static void mainMenu()
	{
		for(int i=0;i<30;i++)
		{
			System.out.print("--");
		}
		System.out.println();
		System.out.println("                  MITS HOTEL");
		for(int i=0;i<30;i++)
		{
			System.out.print("--");
		}
		System.out.println();
		
		System.out.println("                 1. Add User");
		System.out.println("                 2. Update User");
		System.out.println("                 3. Remove User");
		System.out.println("                 4. Display Users");
		System.out.println("                 5. Back to main menu");
		System.out.println();
		for(int i=0;i<30;i++)
		{
			System.out.print("--");
		}
		System.out.println();
	}
//	public static void adminLogin()
//	{
//		for(int i=0;i<30;i++)
//		{
//			System.out.print("--");
//		}
//		System.out.println();
//		System.out.println("                  Hi....Admin\n");
//		System.out.println("                  Please login\n");
//		for(int i=0;i<30;i++)
//		{
//			System.out.print("--");
//		}
//	}

}
