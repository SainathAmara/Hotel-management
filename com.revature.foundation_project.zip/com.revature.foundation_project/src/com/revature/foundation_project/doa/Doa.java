package com.revature.foundation_project.doa;

public interface Doa {
	
	public void addNewUser()throws Exception;
	public void updateUser()throws Exception;
	public void removeUser()throws Exception;
	public void displayUser() throws Exception;

}
